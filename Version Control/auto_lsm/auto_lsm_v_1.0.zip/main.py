try:
    import pyautogui
    import os
    import parameter_interpreter_3
    import pico_emeraldWatch_1, FVWatch_2
    import time
    import json
except ImportError as e:
    input(e)

pyautogui.FAILSAFE = False
# Get the directory of the current script
script_dir = os.path.dirname(os.path.realpath(__file__))
# Change the working directory to the script's directory
os.chdir(script_dir)

# generic helpers
def load_from_json(file_name):
    with open(file_name, 'r') as file:
        return json.load(file)

def get_pixel_color(x, y):
    return pyautogui.pixel(x, y)

# Global variables
fv_layout = load_from_json("FV_layout.json")
frame_on_position = tuple(fv_layout['frame on position'])
frame_off_position = tuple(fv_layout['frame off position'])
frame_numberpad_position = tuple(fv_layout['frame numberpad position'])

pico_emerald_layout = load_from_json("pico_emerald_layout.json")
shutter_position = tuple(pico_emerald_layout['shutter_position'])
shutter_on_color = tuple(pico_emerald_layout['shutter_on_color'])

# ==================== FV helpers ==========================
def resolution_clicker(resolution):
    """
    Click the resolution dropdown and select the desired resolution.
    choices are: "64x64", "128x128", "256x256", "512x512", "1024x1024", "2048x2048", "4096x4096"
    """
    if resolution is None:
        return
    
    resolution_str = str(resolution).split('x')[0]  # Extract the number part, e.g., "64" from "64x64"

    # Click the resolution dropdown
    pyautogui.click(fv_layout['resolution dropdown position'])
    time.sleep(0.5)  # Wait for the dropdown to open

    # Click the desired resolution choice based on the provided resolution
    resolution_key = f"resolution choice {resolution_str} position"
    pyautogui.click(fv_layout[resolution_key])
    time.sleep(0.5)  # Wait for the selection to register
    
def average_clicker(average):
    if int(average) <= 1:
        pyautogui.click(frame_off_position)
    else:
        pyautogui.click(frame_on_position)
        pyautogui.click(frame_numberpad_position)
        pyautogui.hotkey('ctrl', 'a')
        pyautogui.typewrite(average)

def click_channel(channel_number):
    """
    Click one channel checkbox using its saved position.
    """
    FV_layout = load_from_json("FV_layout.json")
    position = tuple(
        FV_layout[f'channel_{channel_number}_checkbox_position']
    )

    x, y = position

    # Click slightly inside the checkbox instead of exactly
    # on the saved top-left corner
    pyautogui.click(x + 7, y + 7)
    time.sleep(0.1)

def set_channels(desired_channels):
    """
    Make the FV checkboxes match desired_channels.

    Example:
        set_channels([1, 3, 5])

    Result:
        CH1 -> ON
        CH2 -> OFF
        CH3 -> ON
        CH4 -> OFF
        CH5 -> ON
    """
    for channel in range(1, 6):
        currently_checked = FVWatch_2.checkbox_is_checked(channel)
        should_be_checked = channel in desired_channels

        if currently_checked != should_be_checked:
            click_channel(channel)

def name_typer(order, wavelength, power, average, zoom):
    name = f"{order}-{wavelength}nm-{power}mW-avg{average}-zoom{zoom}"
    if (average == "off" or average == "no" or int(average) == 0):
        name = f"{order}-{wavelength}nm-{power}mW-zoom{zoom}"
    file = load_from_json("FV_layout.json")
    name_bar_position = tuple(file['file name editor position'])
    pyautogui.click(*name_bar_position)
    pyautogui.hotkey('ctrl', 'a')
    pyautogui.typewrite(name)

# ==================== pico emerald helpers ==========================
def shutter_backOn():
    '''
    This function checks the shutter color change every 0.5 second, 
    and returns a boolean True when the color changed to the color on
    for the system shutter.

    '''
    while True:
        current_shutter_color = get_pixel_color(*shutter_position)
        if tuple(current_shutter_color) == shutter_on_color:
            return True
        time.sleep(0.5)  # Check the shutter every 0.5 second


def main():
    print("Before you use this script, make sure that both softwares are not covered by each other, "
    "and max the window of pico_emerald")

    if not (os.path.exists('pico_emerald_layout.json') and os.path.exists('wavelength_power_keypad.json')):
        input("pico-emerald software layout did not setup! press 'enter' to quit")
        exit(1)

    if not os.path.exists('FV_layout.json'):
        input("fv-30s software layout did not setup! press 'enter' to quit")
        exit(1)

    while True:
        try:
            # Get user input and try to convert it to an integer
            order = int(input("which order (#th) roi are you taking image of? number only!"))
            break  # Return the integer if conversion is successful
        except ValueError:
            # If conversion fails, prompt the user again
            print("Invalid input. Please enter an integer.")

#    print(order) this make sure the order is stored as a value we want
    while True:
        try:
            # Get user input and try to convert it to an integer
            zoom = float(input("which zoom # are you taking image of? number only!"))
            break  # Return the integer if conversion is successful
        except ValueError:
            # If conversion fails, prompt the user again
            print("Invalid input. Please enter an number.")

    # interprete the data in parameters.txt to parameters.json.
    parameter_interpreter_3.interpreter()
    # load parameters from parameters.json
    parameters = load_from_json("parameters.json")
    wavelengths = tuple(parameters['wavelength'])
    powers = tuple(parameters['power'])
    averages = tuple(parameters['average'])
    channels = tuple(parameters['channel'])
    resolutions = tuple(parameters['resolution'])
    dwell_times = tuple(parameters['dwell time'])

    print(order, '-', wavelengths[0], '-', powers[0], 'mW-avg', averages[0], '-zoom', zoom)
    input("This will be how the name looks like as files, press 'enter' to advance,\n press ctrl + c to quit when you think something went wrong ")

    try:
        lsm_start = tuple(fv_layout['lsm button position'])
        lsm_off_color = tuple(fv_layout['lsm button off color'])
        lsm_colorbar_off_color = tuple(fv_layout['lsm colorbar off color'])
        lsm_colorbar_position = tuple(fv_layout['lsm colorbar position'])
    except KeyError:
        input("FVWatch_2 did not run, FV_layout did not setup correctly, press 'ctrl+c' to exit, press 'enter' to setup")
        FVWatch_2.main()

    print("\n" + "="*60)
    print("IMPORTANT: set the wavelength and power to the first set you need to take!!!!!!!!!!!!!!!!!")
    print("="*60)
    # this is because there is a bug for pico emerald software, if you enter the wavelength
    # which is the same with your current wavelength, the next adjust will not turn of the
    # system shutter, so this program will crash
    input("Press 'enter' to start the auto lsm system")

# Actual Performance of the auto lsm system
    i = 0

    while i < len(wavelengths):
            

       # part 1, first aquisition, when the first time using the script when the parameters are setup by the user 
        if i == 0:
            average_clicker(averages[i])
            resolution_clicker(resolutions[i])
            name_typer(order, wavelengths[i], powers[i], averages[i], zoom)
            pico_emeraldWatch_1.change_IR(channels[i])
            set_channels(channels[i])

            if shutter_backOn():
                pyautogui.click(*lsm_start)
                time.sleep(2.8)
                # monitering start, lsm start, sleep(2.8) gives the lsm button to turn into correct working color some time, 10 us gives 3.16
                while True:
                    current_lsm_color = get_pixel_color(*lsm_start)
                    if tuple(current_lsm_color) == lsm_off_color:
                        break # break when lsm finished
                    time.sleep(0.5) # the color of the button is checked every 0.5 second
                i += 1

        # part 2, second aquisition, changing the IR, power, and then the wavelength, and the name of the file, and channels
        if i >= len(wavelengths):
            break # if there is only one set of parameters

            # update average if necessary
        if int(averages[i]) != int(averages[i-1]):
            average_clicker(averages[i])

            # update resolution if necessary
        if resolutions[i] != resolutions[i-1]:
            resolution_clicker(resolutions[i])

        if powers[i] != powers[i-1]:
            pico_emeraldWatch_1.change_power_to(powers[i])
            time.sleep(0.25)
        else:
            pass

        pico_emeraldWatch_1.change_IR(channels[i])
        pico_emeraldWatch_1.change_wavelength_to(wavelengths[i])

        set_channels(channels[i])

        time.sleep(0.5)
        name_typer(order, wavelengths[i], powers[i], averages[i], zoom)

        # part 4, when tuned ok, then click on the lsm start
        if shutter_backOn():
            pyautogui.click(*lsm_start)
            time.sleep(2.8)
            while True:
                current_lsm_color = get_pixel_color(*lsm_start)
                if current_lsm_color == lsm_off_color:
                    break # break when lsm finished
                time.sleep(0.5) # the color of the button is checked every 0.5 second
        i += 1

    pico_emeraldWatch_1.change_power_to(powers[0])
    time.sleep(0.25)
    pico_emeraldWatch_1.change_wavelength_to(wavelengths[0])

main()
